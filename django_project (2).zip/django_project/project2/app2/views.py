from django.shortcuts import render, HttpResponse, get_object_or_404
from app2.models import ACC

# Create your views here.
def index(request):
	return render(request,'index.html')

def AC(request):
	if request.method == "GET":
		Serialnumber = request.GET.get('Serialnumber')
		modelname = request.GET.get('modelname')
		capesity = request.GET.get('capesity')
		AA = ACC(Serialnumber=Serialnumber,modelname=modelname,capesity=capesity)
		AA.save()
		return render(request,'index.html')


def read(request):
	data = ACC.objects.all()
	return render(request,'read.html',{'data':data})


def update(request):
	return render(request,'update.html')


def update_data(request):
	Serialnumber = request.GET.get('Serialnumber')
	change = get_object_or_404(ACC,Serialnumber=Serialnumber)
	if request.method == "GET":
		new_modelname = request.GET.get('modelname')
		new_Serialnumber= request.GET.get('Serialnumber')
		new_capesity = request.GET.get('capesity')
		change.modelname = new_modelname 
		change.Serialnumber = new_Serialnumber
		change.capesity = new_capesity
		change.save()

	return render(request,'update.html')

def delete(request):
	return render(request,'delete.html')


def delete_data(request):
	modelname = request.GET.get('modelname')
	change =  get_object_or_404(ACC,modelname=modelname)
	if request.method == "GET":
		change.delete()
	return render(request,'delete.html')


def Search(request):
	return render(request,"Search.html")

def Search_data(request):
		modelname = request.GET.get('modelname')
		data = ACC.objects.filter(modelname=modelname)
		return render(request,"read.html",{"data":data})
	

