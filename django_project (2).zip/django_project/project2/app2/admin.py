from django.contrib import admin
from app2.models import ACC

# Register your models here.
admin.site.register(ACC)
