from django.contrib import admin
from django.urls import path,include
from app2 import views

urlpatterns = [
    path('',views.index),
    path('AC',views.AC),
    path('read',views.read),
    path('update',views.update),
    path('update-data',views.update_data),
    path('delete',views.delete),
    path('delete-data',views.delete_data),
    path('Search',views.Search),
    path('Search-data',views.Search_data),

]
